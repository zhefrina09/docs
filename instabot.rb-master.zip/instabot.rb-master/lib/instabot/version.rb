module Version
  VERSION     = '0.1.90'.freeze
  SUMMARY     = 'Ruby instagram bot'.freeze
  DESCRIPTION = 'An instagram bot works without instagram api, only needs your username and password'.freeze
end
